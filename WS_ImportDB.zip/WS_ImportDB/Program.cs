﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace WS_ImportDB
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Перетащите файл для импорта в окно");
            string FileWayString = Console.ReadLine();
            string line;
            
            int ArrayLength = 0;
            int j = 0;
            StreamReader sr = new StreamReader(FileWayString);
            while ((line = sr.ReadLine()) != null)
            {
                ArrayLength++;
            }
            string[] FileToString = new string [ArrayLength];
            Console.WriteLine("Array created of {0}", ArrayLength);
            sr.Close();
            StreamReader sr1 = new StreamReader(FileWayString, System.Text.Encoding.Default);
            while ((line = sr1.ReadLine()) != null)
            {
                FileToString[j] = line;
                //Console.WriteLine(FileToString[j]);
                j++;
            }
            string[,] StringToDB = new string[ArrayLength, 6];
            for(int i = 0; i < ArrayLength; i++)
            {
                string[] words = FileToString[i].Split(';');
                for ( j = 0; j < 5; j++)
                {

                    StringToDB[i, j] = words[j];
                }
            }
            SellDBEntities DB = new SellDBEntities();
            for(int i = 0; i < ArrayLength; i++)
            {
                Naimenovanie obj1 = new Naimenovanie()
                {
                    Articul = StringToDB[i, 0],
                    Naimenovanie1 = StringToDB[i, 1],
                    Height = Convert.ToInt32(StringToDB[i, 2]),
                    Width = Convert.ToInt32(StringToDB[i, 3]),
                    Price = Convert.ToInt32(StringToDB[i, 4])
                };
                DB.Naimenovanie.Add(obj1);
                DB.SaveChanges();
            }
            Console.WriteLine("Transfer Complete!");
            Console.ReadKey();
        }
    }
}
