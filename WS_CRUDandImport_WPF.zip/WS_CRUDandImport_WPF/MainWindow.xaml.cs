﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WS_CRUDandImport_WPF
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public bool ViewModel { get; set; }
        public MainWindow()
        {
            InitializeComponent();
            SellDBEntities DB = new SellDBEntities();
            this.DB_Sell.ItemsSource = DB.Naimenovanie.ToList();
        }
        private int updatingSellID = 0;
        private void DB_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if(this.DB_Sell.SelectedIndex >= 0)
            {
                if (this.DB_Sell.SelectedItems.Count >= 0)
                {
                    if(this.DB_Sell.SelectedItems[0].GetType() == typeof(Naimenovanie))
                    {
                        Naimenovanie EditObj = (Naimenovanie)this.DB_Sell.SelectedItems[0];
                        ArticulBox.Text = EditObj.Articul;
                        NaimBox.Text = EditObj.Naimenovanie1;
                        HeightBox.Text = EditObj.Height.ToString();
                        WidthBox.Text = EditObj.Width.ToString();
                        PriceBox.Text = EditObj.Price.ToString();
                        updatingSellID = EditObj.id;
                    }
                }
            }
        }
       
        private void AddItem_Click(object sender, RoutedEventArgs e)
        {
            SellDBEntities DB = new SellDBEntities();
            if (Int32.TryParse(WidthBox.Text.ToString(), out int WRaw) && Int32.TryParse(HeightBox.Text.ToString(), out int HRaw) && Int32.TryParse(PriceBox.Text.ToString(), out int PRaw))
            {
                Naimenovanie AddingObj = new Naimenovanie()
                {
                    Articul = ArticulBox.Text.ToString(),
                    Naimenovanie1 = NaimBox.Text.ToString(),
                    Height = HRaw,
                    Width = WRaw,
                    Price = PRaw
                };
                DB.Naimenovanie.Add(AddingObj);
                DB.SaveChanges();
                MessageBox.Show("Sell", "Товар успешно добавлен", MessageBoxButton.OK);
            }
            else
            {
                MessageBox.Show("Error", "Товар неуспешно добавлен", MessageBoxButton.OK);

            }
            this.DB_Sell.ItemsSource = DB.Naimenovanie.ToList();
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            SellDBEntities DB = new SellDBEntities();
            var r = from d in DB.Naimenovanie
                              where d.id == updatingSellID
                              select d;
            Console.WriteLine(updatingSellID);
            Naimenovanie obj = r.SingleOrDefault();
            if (obj != null)
            {
                MessageBox.Show(ArticulBox.Text + "\n" + NaimBox.Text + "\n" + Convert.ToInt32(HeightBox.Text) + "\n" + Convert.ToInt32(WidthBox.Text) + "\n" + Convert.ToInt32(PriceBox.Text));
                    obj.Articul = ArticulBox.Text.ToString();
                    obj.Naimenovanie1 = NaimBox.Text;
                    obj.Height = Convert.ToInt32(HeightBox.Text);
                    obj.Width = Convert.ToInt32(WidthBox.Text);
                    obj.Price = Convert.ToInt32(PriceBox.Text);
            }
            else
            {
                MessageBox.Show("NULL");
            }
            DB.SaveChanges();
            this.DB_Sell.ItemsSource = DB.Naimenovanie.ToList();
        }

        private void removeButton_Click(object sender, RoutedEventArgs e)
        {
            SellDBEntities DB = new SellDBEntities();
            var r = from d in DB.Naimenovanie
                    where d.id == updatingSellID
                    select d;
            Console.WriteLine(updatingSellID);
            Naimenovanie obj = r.SingleOrDefault();
            if (obj != null)
            {
                MessageBoxResult result = MessageBox.Show("Удалить товар?", "", MessageBoxButton.YesNo);
                switch (result)
                {
                    case MessageBoxResult.Yes:
                        DB.Naimenovanie.Remove(obj);
                        DB.SaveChanges();
                        break;
                }

            }
            DB.SaveChanges();
            this.DB_Sell.ItemsSource = DB.Naimenovanie.ToList();

        }
    }
}
