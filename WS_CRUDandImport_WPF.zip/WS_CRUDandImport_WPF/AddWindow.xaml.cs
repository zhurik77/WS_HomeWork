﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WS_CRUDandImport_WPF
{
    /// <summary>
    /// Логика взаимодействия для AddWindow.xaml
    /// </summary>
    public partial class AddWindow : Window
    {
        public int a;
        public AddWindow()
        {
            InitializeComponent();
            SellDBEntities DB = new SellDBEntities();
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            if (Int32.TryParse(WidthBox.Text.ToString(), out int WRaw)&& Int32.TryParse(HeightBox.Text.ToString(), out int HRaw)&& Int32.TryParse(PriceBox.Text.ToString(), out int PRaw))
            {
                Naimenovanie AddingObj = new Naimenovanie()
                {
                    Articul = ArticulBox.Text.ToString(),
                    Naimenovanie1 = NaimBox.Text.ToString(),
                    Height = HRaw,
                    Width = HRaw,
                    Price = PRaw
                };
                SellDBEntities DB = new SellDBEntities();
                DB.Naimenovanie.Add(AddingObj);
                DB.SaveChanges();
                MessageBox.Show("Sell", "Товар успешно добавлен", MessageBoxButton.OK);
                MainWindow mainWindow = new MainWindow();
                mainWindow.DB_Sell.ItemsSource = DB.Naimenovanie.ToList();
                this.Close();
            }
            else
            {
                MessageBox.Show("Error", "Проверьте правильность введнных данных!", MessageBoxButton.OK);
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
